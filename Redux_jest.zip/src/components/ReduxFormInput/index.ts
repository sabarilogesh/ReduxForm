import ReduxFormInput from './ReduxFormInput';
export default ReduxFormInput;