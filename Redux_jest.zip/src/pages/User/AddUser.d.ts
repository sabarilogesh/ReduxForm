export interface AddUserParams {
    userName: string;
    userDOB: string;
    userAge: string;
    userGender: string;
    userMobileNumber: string;
    userAddress: string;
    useraccountNumber: string;
    userBankName: string;
    userbankAddress: string;
}