import React from 'react';
import User from './pages/User';
import './App.css';

const App: React.FC = () => {
  return (
    <div>
      <User />
    </div>
  );
}

export default App;
